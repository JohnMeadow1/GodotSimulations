/* water.cpp */
#include "water.h"

Water::~Water() {
	memdelete(buffer1);
	memdelete(buffer2);
	memdelete(bufferm1);
	memdelete(temp_buffer);
}

Water::Water() {
}

void Water::init(int w, int h, const Ref<ImageTexture>& p_texture) {
	set_texture(p_texture);
	width  = w;
	height = h;

	buffer1     = memnew(PoolVector<uint8_t>);
	buffer2     = memnew(PoolVector<uint8_t>);
	bufferm1    = memnew(PoolVector<uint8_t>);
	temp_buffer = memnew(PoolVector<uint8_t>);

	buffer1->resize(    width * height);
	buffer2->resize(    width * height);
	bufferm1->resize(   width * height);
	temp_buffer->resize(width * height);

	PoolVector<uint8_t>::Write write      = buffer1->write();
	PoolVector<uint8_t>::Write write_back = buffer2->write();
	PoolVector<uint8_t>::Write write_m1   = bufferm1->write();
	PoolVector<uint8_t>::Write write_temp = temp_buffer->write();
	for (int i = 0; i < width*height; i++) {
		write[i]      = 0;
		write_back[i] = 0;
		write_m1[i]   = 0;
		write_temp[i] = 0;
	}
	write      = PoolVector<uint8_t>::Write();
	write_back = PoolVector<uint8_t>::Write();
	write_m1   = PoolVector<uint8_t>::Write();
	write_temp = PoolVector<uint8_t>::Write();
	//image->create(width, height, false, Image::FORMAT_L8, *buffer1);
	image->create(width, height, false, Image::FORMAT_L8, *buffer1);
	texture_ref->create_from_image(image, texture_ref->FLAG_VIDEO_SURFACE);
}

void Water::update(float propagation = 1.0) {
	// copy
	
	PoolVector<uint8_t>::Read read      = buffer2->read();
	PoolVector<uint8_t>::Write write    = temp_buffer->write();
	PoolVector<uint8_t>::Write write_m1 = bufferm1->write();
	for (int i = 0; i < width*height; i++) {
		write[i] = read[i];
	}
	// operation
	write = buffer2->write();
	read = buffer1->read();
	PoolVector<uint8_t>::Read read_temp = temp_buffer->read();
	PoolVector<uint8_t>::Read read_m1   = bufferm1->read();

	for (int i = 0; i < width*height; i++) {
		float sum = 0;

		int x = i % width;
		int y = i / width;


		if (x > 0 && x < width - 1 && y > 0 && y < height - 1) {
			sum += read[(y - 1)*width + x];
			sum += read[y*width       + x - 1];
			sum += read[y*width       + x + 1];
			sum += read[(y + 1)*width + x];
		}
		sum = sum -( float(read[i]) * 4.0);
		sum = float(read[i]) * 2.0 - float(read_m1[i]) + propagation * sum;
		uint8_t realValue = MAX(0, MIN(255, sum));

		write_m1[i] = read[i];
		write[i] = realValue;
	}

	// release

	write     = PoolVector<uint8_t>::Write();
	read      = PoolVector<uint8_t>::Read();
	write_m1  = PoolVector<uint8_t>::Write();
	read_m1   = PoolVector<uint8_t>::Read();
	read_temp = PoolVector<uint8_t>::Read();

	//swap

	PoolVector<uint8_t> * tmp_buffer = buffer1;
	buffer1 = buffer2;
	buffer2 = tmp_buffer;

	//image.create(width, height, false, Image::FORMAT_L8, *bufferm1);
	image->create(width, height, false, Image::FORMAT_L8, *bufferm1);
	texture_ref->set_data( image );
	
}

void Water::set_texture(const Ref<ImageTexture>& p_texture) {
	texture_ref = p_texture;
}

Ref<ImageTexture> Water::get_texture() const {
	return texture_ref;
}

void Water::touch(Vector2 coords, int radius = 0) {
	
	int y_min = MAX(0       , coords.y - radius);
	int y_max = MIN(height-1, coords.y + radius);
	int x_min = MAX(0       , coords.x - radius);
	int x_max = MIN(width-1 , coords.x + radius);
	float radius_sqare = MAX(1,radius*radius);

	PoolVector<uint8_t>::Write write  = buffer1->write();
	PoolVector<uint8_t>::Write write2 = buffer2->write();

	int dx = 0; // horizontal offset
	int dy = 0; // vertical offset
	for (int y = y_min; y <= y_max; y++) {
		for (int x = x_min; x <= x_max; x++) {
			dx = coords.x - x;
			dy = coords.y - y;
			float distance_from_center = dx*dx + dy*dy;
			if (distance_from_center <= radius_sqare)	{
				write [y*width + x] = 255 * (radius_sqare - distance_from_center) / radius_sqare;
				write2[y*width + x] = 255 * (radius_sqare - distance_from_center) / radius_sqare;
			}
		}
	}
	//write [coords.y*width + coords.x] = 255;
	//write2[coords.y*width + coords.x] = 255;
	write  = PoolVector<uint8_t>::Write();
	write2 = PoolVector<uint8_t>::Write();
	
}

void Water::_bind_methods() {
	ClassDB::bind_method(D_METHOD("update"), &Water::update);
	ClassDB::bind_method(D_METHOD("init", "width", "height", "texture"), &Water::init);
	ClassDB::bind_method(D_METHOD("get_texture"), &Water::get_texture);
	ClassDB::bind_method(D_METHOD("set_texture"), &Water::set_texture);
	ClassDB::bind_method(D_METHOD("touch", "coords", "radius"), &Water::touch, DEFVAL(0));
}
