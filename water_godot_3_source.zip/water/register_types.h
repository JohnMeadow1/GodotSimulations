/* register_types.h */
void register_water_types();
void unregister_water_types();
