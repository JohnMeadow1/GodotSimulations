def can_build(platform):
  return True  

def configure(env):
  pass
