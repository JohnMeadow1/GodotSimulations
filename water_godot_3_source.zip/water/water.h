#ifndef WATER_H
#define WATER_H

#include "dvector.h"
#include "image.h"
#include "scene/resources/texture.h"
#include "reference.h"

class Water : public Reference {
	GDCLASS(Water, Reference);

	PoolVector<uint8_t> * buffer1;
	PoolVector<uint8_t> * buffer2;
	PoolVector<uint8_t> * bufferm1;
	PoolVector<uint8_t> * temp_buffer;
	//Image image;
	//const Ref<Image> image;
	//Ref<Image> image;
	Ref<Image> image = memnew(Image);

	int width;
	int height;
	Ref<ImageTexture> texture_ref;

	protected:
		static void _bind_methods();
	public:
		Water();
		~Water();
		void init(int w, int h, const Ref<ImageTexture>& p_texture);
		void set_texture(const Ref<ImageTexture>& p_texture);
		Ref<ImageTexture> get_texture() const;
		void touch(Vector2 coords, int radius);
		void update(float propagation);

};

#endif // WATER_H
